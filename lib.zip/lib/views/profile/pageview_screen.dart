import 'package:dating_app/controller/profile_controller.dart';
import 'package:dating_app/views/homeScreen/home_screen.dart';
import 'package:dating_app/views/profile/appearance.dart';
import 'package:dating_app/views/profile/background.dart';
import 'package:dating_app/views/profile/lifestyle.dart';
import 'package:dating_app/views/profile/personal_info.dart';
import 'package:dating_app/views/profile/profile_name.dart';
import 'package:dating_app/views/profile/profile_pic.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';


class PageViewScreen extends StatefulWidget {
  const PageViewScreen({super.key});

  @override
  State<PageViewScreen> createState() => _PageViewScreenState();
}

class _PageViewScreenState extends State<PageViewScreen> {
  var profilecontroller = Get.put(ProfileController());
  final pageController = PageController();
  int currentIndex = 0;
  List<Widget> pages = [Profile(), ProfilePic(), PersonalInfo(), AppearanceDetails(), LifeStyleDetails(), BackgroundDetails()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: PageView(
              controller: pageController,
              children: pages,
              onPageChanged: (index){
                currentIndex = index;
                if(currentIndex == 1){
                  profilecontroller.fillName(name:nameController.text);
                }elseif(currentIndex == 2){
                  profilecontroller.fillPersonalInfoDetails(email, age, phoneNo, city, country, profileHeading, lookingForInAPartner);
                }elseif(currentIndex == 3){
                  profilecontroller.fillAppearanceDetails(height, weight, bodyType);
                }elseif( currentIndex == 4){
                  profilecontroller.fillLifeStyleDetails(drink, smoke, maritalStatus, haveChildren, noOfChildren, livingSituation, willingToRelocate, relationshipYouAreLookingFor);
                }elseif( currentIndex == 5){
                  profilecontroller.fillBackgroundDetails(profession, employmentStatus, income, nationality, education, languageSpoken, religion, ethnicity);
                };
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.deepOrange,
        elevation: 0,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Icon(Icons.visibility),
            Text(
              "This will be shown in your profile",
              softWrap: true,
              style: TextStyle(
                decoration: TextDecoration.none,
                color: Colors.black,
                fontSize: 15,
                fontFamily: 'Caveat',
              ),
            ),
            IconButton(
              onPressed: () {
                if(currentIndex == pages.length-1){
                  Get.to(()=>HomeScreen());
                }else{
                pageController.nextPage(duration: Duration(milliseconds: 500), curve: Curves.linearToEaseOut);
                }
              },
              color: Colors.black,
              splashColor: Colors.amber,
              style: ButtonStyle(backgroundColor: MaterialStateProperty.all(Colors.white)),
              icon: Icon(Icons.arrow_forward_ios_outlined),
            ),
          ],
        ),
      ),
    );
  }
}
